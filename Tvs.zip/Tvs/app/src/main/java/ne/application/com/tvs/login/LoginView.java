package ne.application.com.tvs.login;

/**
 * Created by Harikesh on 28/03/2019.
 */
public interface LoginView {
}
